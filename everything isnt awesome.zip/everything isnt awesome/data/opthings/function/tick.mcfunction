execute as @e[type=item] if items entity @s contents diamond if data entity @s Thrower at @s if block ~ ~-1 ~ diamond_block align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=diamond_crop,distance=..0.1] if block ~ ~ ~ #replaceable run summon item_display ~ ~ ~ {Tags:[diamond_crop,diamond_crop_root],Passengers:[{id:item_display,Tags:[diamond_crop],item:{id:diamond},transformation:[1,0,0,0,0,1,0,-0.25,0,0,0.01,0.25,0,1,0,1]},{id:item_display,Tags:[diamond_crop],item:{id:diamond},transformation:[1,0,0,0,0,1,0,-0.25,0,0,0.01,0.25,0,1,0,1],Rotation:[90,0]},{id:item_display,Tags:[diamond_crop],item:{id:diamond},transformation:[1,0,0,0,0,1,0,-0.25,0,0,0.01,0.25,0,1,0,1],Rotation:[180,0]},{id:item_display,Tags:[diamond_crop],item:{id:diamond},transformation:[1,0,0,0,0,1,0,-0.25,0,0,0.01,0.25,0,1,0,1],Rotation:[-90,0]},{id:interaction,Tags:[diamond_crop,diamond_crop_interact],width:1,height:0.5}],data:{grow_stage:[-1,0,1,2,3]}}

execute as @e[type=item] if items entity @s contents diamond if data entity @s Thrower at @s if block ~ ~-1 ~ diamond_block align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=diamond_crop,tag=init,distance=..0.1] if block ~ ~ ~ #replaceable run playsound block.stone.break block @a ~ ~ ~ 0.75 1.75

execute as @e[type=item] if items entity @s contents diamond if data entity @s Thrower at @s if block ~ ~-1 ~ diamond_block align xyz positioned ~0.5 ~ ~0.5 unless entity @e[tag=diamond_crop,tag=init,distance=..0.1] if block ~ ~ ~ #replaceable run item modify entity @s contents {function:set_count,count:-1,add:1}

tag @e[tag=diamond_crop,tag=!init] add init

execute as @e[tag=diamond_crop_root] if predicate {condition:random_chance,chance:0.005} run tag @s add grow

execute as @e[tag=diamond_crop_root,tag=grow] at @s on passengers store result entity @s transformation.translation[1] double 0.125 if data entity @n[tag=diamond_crop_root] data.grow_stage[0] run data get entity @n[tag=diamond_crop_root] data.grow_stage[0]

execute as @e[tag=diamond_crop_root,tag=grow] run data remove entity @s data.grow_stage[0]

execute as @e[tag=diamond_crop_root,tag=grow] unless data entity @s data.grow_stage[0] run tag @s add diamond_crop_full

tag @e[tag=diamond_crop_root,tag=grow] remove grow

execute as @e[tag=diamond_crop_interact] if data entity @s attack on vehicle unless entity @s[tag=diamond_crop_full] at @s run loot spawn ~ ~ ~ loot {pools:[{rolls:1,entries:[{type:item,name:diamond}]}]}

execute as @e[tag=diamond_crop_interact] if data entity @s attack on vehicle if entity @s[tag=diamond_crop_full] at @s run loot spawn ~ ~ ~ loot {pools:[{rolls:1,entries:[{type:item,name:diamond,functions:[{function:set_count,count:{min:3,max:6}}]}]}]}

execute as @e[tag=diamond_crop_interact] if data entity @s attack at @s run playsound block.stone.break block @a ~ ~ ~ 0.75 2

execute as @e[tag=diamond_crop_interact] if data entity @s attack at @s run particle item{item:{id:diamond}} ~ ~0.1 ~ 0.2 0.2 0.2 0 10

execute as @e[tag=diamond_crop_interact] if data entity @s attack at @s run kill @e[tag=diamond_crop,distance=..0.1]