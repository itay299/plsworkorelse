item replace entity itay200 armor.feet with netherite_boots[trim={material:emerald,pattern:dune},enchantments={protection:4,feather_falling:4,soul_speed:3,depth_strider:3,unbreaking:3,mending:1}]

item replace entity itay200 armor.legs with netherite_leggings[trim={material:emerald,pattern:ward},enchantments={protection:4,swift_sneak:3,unbreaking:3,mending:1}]

item replace entity itay200 armor.chest with netherite_chestplate[trim={material:emerald,pattern:snout},enchantments={protection:4,unbreaking:3,mending:1}]

item replace entity itay200 armor.head with netherite_helmet[trim={material:emerald,pattern:dune},enchantments={protection:4,respiration:3,aqua_affinity:1,unbreaking:3,mending:1}]