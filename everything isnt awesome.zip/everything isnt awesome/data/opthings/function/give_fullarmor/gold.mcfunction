item replace entity itay200 armor.feet with iron_boots[enchantments={protection:4,feather_falling:4,unbreaking:3,mending:1}]

item replace entity itay200 armor.legs with iron_leggings[enchantments={protection:4,unbreaking:3,mending:1}]

item replace entity itay200 armor.chest with iron_chestplate[enchantments={protection:4,unbreaking:3,mending:1}]

item replace entity itay200 armor.head with iron_helmet[enchantments={protection:4,respiration:3,aqua_affinity:1,unbreaking:3,mending:1}]