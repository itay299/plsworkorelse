give itay200 stone_sword[enchantments={sharpness:5,unbreaking:3,mending:1,sweeping_edge:3,looting:3,fire_aspect:2}]

give itay200 stone_pickaxe[enchantments={efficiency:5,unbreaking:3,mending:1,fortune:3}]